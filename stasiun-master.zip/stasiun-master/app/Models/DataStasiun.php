<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DataStasiun extends Model
{
    use HasFactory;

    protected $table = 'datastasiun';
    protected $guarded = [];
}
