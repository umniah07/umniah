<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">© 2023 {{ config('app.name') }}</div>
        </div>
    </div>
</footer><!-- End Footer -->
<!-- jQuery  -->
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/js/jquery.min.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/js/popper.min.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/js/bootstrap.min.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/js/modernizr.min.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/js/waves.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/js/jquery.slimscroll.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/js/jquery.nicescroll.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/js/jquery.scrollTo.min.js"></script><!-- KNOB JS -->
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/plugins/jquery-knob/excanvas.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/plugins/jquery-knob/jquery.knob.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/plugins/chart.js/chart.min.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/pages/dashboard.js"></script><!-- App js -->
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/plugins/datatables/dataTables.bootstrap4.min.js"></script><!-- Buttons examples -->
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/plugins/datatables/dataTables.buttons.min.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/plugins/datatables/buttons.bootstrap4.min.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/plugins/datatables/jszip.min.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/plugins/datatables/pdfmake.min.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/plugins/datatables/vfs_fonts.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/plugins/datatables/buttons.html5.min.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/plugins/datatables/buttons.print.min.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/plugins/datatables/buttons.colVis.min.js"></script><!-- Responsive examples -->
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/plugins/datatables/dataTables.responsive.min.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/plugins/datatables/responsive.bootstrap4.min.js"></script><!-- Datatable init js -->
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/pages/datatables.init.js"></script><!-- App js -->
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/plugins/x-editable/js/bootstrap-editable.min.js"></script>
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/pages/xeditable.js"></script><!-- App js -->
<script src="{{ asset('Zoogler/mannatthemes.com/zoogler/horizontal') }}/assets/js/app.js"></script>


</body>
</html>
